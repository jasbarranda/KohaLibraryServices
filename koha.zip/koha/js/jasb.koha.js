	document.getElementById("SearchForm").onkeypress = function(e) { var key = e.charCode || e.keyCode || 0; if (key == 13) { e.preventDefault(); }}
	$('#translControl1').keyup(function(e){ if (e.keyCode == 13){  GetBibliographicData(); } });
	//==================================================================================================================================================
	        function AdvanceSearch(){
                        //if(isEmptyInline(document.forms.SearchForm.masthead_search,"masthead_search", "masthead_search")) return false;
                        //if(isEmptyInline(document.forms.SearchForm.translControl1,"translControl1", "Type search term")) return false;
                        var SearchUrl = "idx="+$("#masthead_search").val()+"&q="+$("#translControl1").val()+"&weight_search=1";
                        var SiteUlr = "advance-search.php?"+SearchUrl;
                        
                        window.open(SiteUlr,"_SELF");    
	        }
	//=============================================================================================================================================================================
	        function GetBibliographicData(){
                    //if(isEmptyInline(document.forms.SearchForm.masthead_search,"masthead_search", "masthead_search")) return false;
                    //if(isEmptyInline(document.forms.SearchForm.translControl1,"translControl1", "Type search term")) return false;
                    var Loading  = '<div class="text-center m-t-lg clearfix wrapper-lg animated" id="galleryLoading"><h4>Bibliographic Data</h4>';
	            Loading += '<h5 class="text-muted" id="LoadStatus">loading...</h5><p class="m-t-lg"><i class="fa fa-spinner fa fa-spin fa fa-2x"></i></p></div>';
	            $("#LoadCatalogList").html(Loading);
		        $.ajax({
			        url: "getjson.php",
			        //url: "http://prosentient.intersearch.com.au/cgi-bin/koha/svc/report?id=1&annotated=1",
			        type: "post",
			        data: { idx : $("#masthead_search").val(), q : $("#translControl1").val() },
			        //dataType: "json",
			        success: function(data){ 
                                        $('#LoadCatalogList').html(data);
			        },
			        error: function(jqXHR, textStatus, errorThrown){
                                        $("#LoadStatus").html('error loading...'  + textStatus + ' - ' + errorThrown); 
                                }  
		        });
	
	        }
	//==================================================================================================================================================
		function isEmptyInline(frmField,fldId,fldName){
		        var fld = frmField.value; var ctr=0; var len = fld.length;
		        for(var i=0;i<=len;i++){ if (fld.charAt(i)==" ") ctr++; }
		        if (len==ctr){ $("#Grp"+fldId).addClass('has-error'); frmField.focus(); return true; 
		        }else{ $("#Grp"+fldId).removeClass('has-error'); }
		return false;
	        }
        //==================================================================================================================================================
