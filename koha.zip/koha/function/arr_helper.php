<?php	
	class arr_function{
		
		function nav_list(){
		        $navlist = array("About the catalogue"=>"https://prosentient.intersearch.com.au/cgi-bin/koha/opac-showpage.pl?pageid=About%20the%20Prosentient%20library%20catalogu",
		                         "Prosentient Systems Koha Services"=>"https://www.prosentient.com.au/index.php/koha",
		                         "Prosentient Systems"=>"https://www.prosentient.com.au/");
			 
			return json_decode(json_encode($navlist)); 
		}
		
		function search_list(){
		        $searchlist = array("Home"=>"index.php",
		                         "Advanced search"=>"advance-search.php",
		                         "Course reserves"=>"course-reserves.php",
		                         "Authority search"=>"authority-search.php",
		                         "Tag cloud"=>"tag-cloud.php",
		                         "Libraries"=>"libraries.php");
			 
			return json_decode(json_encode($searchlist)); 
		}
		
		function lib_catalog_list(){
		        $catlist = array("~Library catalogue~"=>"",
		                         "Keyword phrase"=>"kw,phr",
		                         "Title"=>"ti",
		                         "Author"=>"au",
		                         "Subject"=>"su",
		                         "ISBN"=>"nb",
		                         "ISSN"=>"ns",
		                         "Series"=>"se",
		                         "Notes/Comments"=>"nt",
		                         "Call number"=>"callnum");
			 
			return json_decode(json_encode($catlist)); 
		}
		
		function overview_list(){
		        $navlist = array("<p><i>Koha</i> is an open source Integrated Library System used globally by thousands of libraries of all kinds: public, educational, corporate, governmental and special. Koha's Open Source Library Management System (meaning 'gift' in Māori) was developed by the Horowhenua Library Trust in New Zealand in 1999. As an <a href=\"https://www.prosentient.com.au/about/opensource\">open source system</a>, Koha is free to download, install and use.</p>",
		                        "<p>Koha is a robust solution covering all library functions.  The community releases new versions 6-monthly and security patches when required.   We have undertaken detailed penetration tests for Koha.</p>",
		                        "<p>Koha’s Online Public Access Catalog (OPAC) and its Staff Client are both web-based, requiring a web browser such as Microsoft Edge, Firefox, Chrome or Safari. Koha can be used from Windows, Macintosh and Linux desktops, tablets and smart phone devices. The user interface is very configurable and the OPAC can be customised to provide a simple portal to an information centre on the intranet.</p>",
		                        "<p>In offering a fully hosted services platform for Koha we aim to solve the practical problems libraries have in actually deploying the Koha LMS. Providing a web-enabled server to run it on, installing and configuring the application, migrating existing data, training staff and sourcing the technical skills to support and update the software are non-trivial undertakings for many library operations.</p>",
		                        "<p><h4><a href=\"https://www.prosentient.com.au/koha/gallery\">Have a look at our gallery for example projects.</a></h4></p>",
		                        "<p>Koha's sophisticated modules include:</p>",
		                        "<p>
                                        <ul class='ul-mod'>
                                                <li>Administration/ Management Facilities for Special Library Operations</li>
                                                <li>Online OPAC</li>
                                                <li>Patrons</li>
                                                <li>Robust cataloguing system (MARC-based, supports Z39.50, with the option to fetch entries from Libraries Australia directly)</li>
                                                <li>Searching</li>
                                                <li>Circulation system (including self-checkout option)</li>
                                                <li>Acquisitions, Budgeting & Serials Management</li>
                                                <li>Reporting</li>
                                                <li>Library 2.0 facilities (tags, suggestions, Amazon & Google's book jackets)</li>
                                        </ul>
                                        </p>",
                                        "<p>On top of that there are the extra tools, extensions and know-how that only come from detailed experience with the application. Extras we have introduced include:</p>");
			 
			return json_decode(json_encode($navlist)); 
		}		
		
	}

	 $arrfunc = new arr_function();
?>
