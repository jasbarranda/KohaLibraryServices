<?php	
	class jasb_function{
		function connect(){
			global $jasbconf;
			$this->link = mysql_connect($jasbconf->dbHost, $jasbconf->dbUsername, $jasbconf->dbPassword) or die(mysql_error());
			mysql_select_db($jasbconf->dbName) or die(mysql_error());
		}
		
		function query($query){
			$this->result = mysql_query($query) or die(mysql_error());
		}
		
		function result(){
			return $this->result;
		}
		
		function numrows(){
			return $this->numrows = mysql_num_rows($this->result);
		}
		
		function lastid(){
			return $this->lastid = mysql_insert_id();
		}
		
		function result_array(){
			while($row = mysql_fetch_array($this->result)) {
				$list[] = $row;
			}
			$this->row = $list;		
			return $this->row;
		}
		
		function affected_rows(){
			return $this->affected_rows = mysql_affected_rows($this->result);
		}
		
		function clean(){
			mysql_free_result($this->result);
		}
		
		function disconnect(){
			mysql_close($this->link);
		}		
	}

	 $jasbfunc = new jasb_function();
?>
