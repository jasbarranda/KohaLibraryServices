<?php
$idx = $_REQUEST['idx'];
$q   = trim($_REQUEST['q']);
$url = 'https://prosentient.intersearch.com.au/cgi-bin/koha/svc/report?id=1&annotated=1';//&idx='.$idx.'&q='.$q;
$json = file_get_contents($url);
foreach(json_decode($json) as $S):
 switch($idx):
        case "ti": $MatchingString = $S->title; break;
        case "au": $MatchingString = $S->author; break;
        case "su": $MatchingString = $S->Subjects; break;
        case "nb": $MatchingString = $S->isbn; break;
        default: $MatchingString = $S->Subjects; break;
 endswitch;
      
      if(preg_match("/".$q."/i",$MatchingString)): ?>
<article class="media" id="cat-id">
        <!--span class="pull-left thumb-sm"><img src="images/avatar_default.jpg" class="img-circle"></span-->
        <span class="pull-left thumb-sm"><i class="fa fa-file-o fa-3x icon-muted"></i></span>
        <div class="media-body" style="font-family:Trebuchet MS;">
                <div class="col-md-12">
                    <small class="block">
         	        <a href="#" class="b" style="font-size:13px;">
		                <?php echo $S->title.' : '.$S->Subjects; ?>
                        </a>
                    </small>
                    
                </div>
                <div class="col-md-9">
                    <small class="block">By: <?php echo $S->author; ?></small>
		    <small class="block">Material type: <?php echo $S->type; ?></small>
	            <small class="block">Publication details: <?php echo $S->copyrightdate; ?></small>
                </div>
                <div class="col-md-3">
		        <div class="pull-right media-xs text-center text-muted">
			        <div class="comment-action m-t-sm">
				        <a class="btn btn-flat btn-info btn-sm" title="Add to Cart"> <i class="fa fa-shopping-cart"></i> Add to Cart
				        </a>
			        </div>
		        </div> 
             </div>
                
        </div>
</article>
<div class="line pull-in" id="line-id"></div>
<?php endif; ?>
<?php endforeach; ?>


