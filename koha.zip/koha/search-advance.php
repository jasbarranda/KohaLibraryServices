<div class="row">
<form id="SearchForm" name="SearchForm" autocomplete="off">
        <div class="col-md-12">
                <div class="m-b-md">
			<h3 class="m-b-none"><i class="fa fa-search"></i> Search</h3> 
			
	        </div>
	</div>
        <div class="col-md-3">
                <select name="idx" id="masthead_search" class="input-sm form-control">
                        <?php foreach($arrfunc->lib_catalog_list() as $catname=>$catcode): ?>
                        <option value="<?php echo $catcode; ?>"><?php echo $catname; ?></option>
                        <?php endforeach; ?>
                </select>
	</div>
	<div class="col-md-9">
		<div class="input-group">
                        <input type="text" id="translControl1" name="q" autocomplete="off" placeholder="Type search term" class="input-sm form-control">
                        <span class="input-group-btn">
                                <a class="btn btn-flat btn-sm btn-primary" onClick="AdvanceSearch()"><i class="fa fa-search"></i> Go Search</a>
                        </span>                  
                </div>	        
	</div>
</form>
</div>
