<?php 
        include("config/config.inc.php");
	include("function/functions.inc.php");
	include("function/arr_helper.php");
?>

<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
		<meta charset="utf-8">
		<link rel="SHORTCUT ICON" href="images/favicon.ico"/>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title><?php echo $jasbconf->title; ?></title> 
		
		<link rel="stylesheet" href="css/font.css" type="text/css">
		<link rel="stylesheet" href="css/app.v1.css" type="text/css"> 
                <link rel="stylesheet" href="css/jasb-koha.css" type="text/css">	
	</head>
	<body class=""> 

	<header class="header bg-light b-b b-light" style="background-color:#FFFFFF;"> 
	        <div class="row" style="padding:10px;">
		        <div class="col-md-12">
		                <div class="col-xs-4">
		                        <img src="images/inter-search.jpg"><br>
		                        <a href="https://www.prosentient.com.au/" style="font-size:16px; vertical-align:bottom;"><?php echo $jasbconf->SystemTitle; ?></a>
		                </div>
		        </div>
	        </div>				
	</header>

<section class="hbox" style="font-family:Trebuchet MS;">
                                <aside class="bg-light lter aside-md hidden-print hidden-xs" id="nav"> 
					<section class="vbox"> 	
					        <section>	
							        <nav class="nav-primary hidden-xs"> 
								        <ul class="nav"> 
					
									        <li class="active"> 
										        <a href="" class="active"> 
											        <i class="fa fa-home icon"> 
											        <b class="bg-danger"></b> </i> 
											        <span class="pull-right"> 
												        <i class="fa fa-angle-down text"></i> 
												        <i class="fa fa-angle-up text-active"></i> 
											        </span> 
											        <span>Home</span> 
										        </a> 
										        <ul class="nav lt">
										        <?php foreach($arrfunc->nav_list() as $nav=>$link): ?>
                                                                                        
										                <li class=""> 
                                                                                                        <a href="<?php echo $link; ?>" class="" 
												                style="font-size:11px;"> 
													        <i class="fa fa-angle-right"></i> 
													        <span><?php echo $nav; ?></span> 
												        </a> 
											        </li>
											<?php endforeach; ?>
										        </ul>
									        </li>
							                </ul>
							        </nav>
					        </section>
					</section> 
				</aside>
				<section id="content">
        <section class="scrollable padder">
        <?php include_once('search-advance.php'); ?>
        <br>
<div class="row">
        <div class="col-md-12">
                <ul class="ul-hr">
                  <?php foreach($arrfunc->search_list() as $mnunme=>$filelnk): ?>
                  <li class="li-hr"><a href="<?php echo $filelnk; ?>"><?php echo $mnunme; ?></a></li>
                  <?php endforeach; ?>
                </ul>        
        </div>
        <div class="col-md-12"> 
                <section class="panel panel-default">
                        <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-12">
                                                <div class="m-b-md">
			                                <h3 class="m-b-none">Authority search</h3> 
			                                <small><?php echo $jasbconf->ModuleTitle; ?></small>
	                                        </div>
	                                </div>
	                            </div>    
                                </div>
                        </div>
                </section> 
        </div>
</div>	

<div class="row extra-forter">
        <div class="col-md-6"><a href="https://prosentient.intersearch.com.au/cgi-bin/koha/opac-reportproblem.pl">Report a problem</a></div>
        <div class="col-md-6 r">Powered by <a href="https://koha-community.org">Koha</a> </div>
        <div class="col-md-12 r">Hosted by <a href="https://prosentient.com.au">Prosentient</a></div>
</div>
                </section>
        </section>
</section>

	<script src="js/app.v1.js"></script> 
	<script src="js/app.plugin.js"></script>
	<script src="js/jasb.koha.js"></script>
	</body>
</html>
