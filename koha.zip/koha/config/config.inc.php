<?php
 	class config_jasb{
 	
		var $dbHost;
		var $dbUsername;
		var $dbPassword;
		var $dbName;
		
		var $rateGroup;
		
		function config_jasb() {
			global $jasbconf;
		 
			$this->dbHost                   = "localhost";
			$this->dbUsername               = "root";
			$this->dbPassword		= "";
			$this->dbName 			= "db_koha";
			
			$this->style		        = "";			
			$this->title			= "Koha online catalogue";
			$this->SystemTitle	        = "Prosentient Systems Website";
			$this->ModuleTitle	        = "Koha Library Services";
			
			$this->timeDefault['from']	= "00:00:00";
			$this->timeDefault['to']	= "23:59:59";			
			
			$this->directory['icons']	= "images/icons/";
			$this->directory['images']	= "images";			
			  
		  	$this->table['catalog'] 	= "catalog";
	 
		}
		
	 }
	 $jasbconf = new config_jasb();
	 
?>
